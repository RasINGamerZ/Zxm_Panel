import os, sqlite3, hashlib, uuid, random, datetime
from fastapi import FastAPI, Form, Request, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

app = FastAPI(title="Zxm Panel v1 UI")
templates = Jinja2Templates(directory="templates")

os.makedirs("static/uploads", exist_ok=True)
os.makedirs("static/css", exist_ok=True)
os.makedirs("static/js", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

DB = "panel.db"
conn = sqlite3.connect(DB, check_same_thread=False)
c = conn.cursor()

# tables (vps includes resources)
c.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT DEFAULT "user", email TEXT, ref_code TEXT, referred_by TEXT)')
c.execute('CREATE TABLE IF NOT EXISTS vps (id INTEGER PRIMARY KEY, user_id INTEGER, name TEXT, os TEXT, status TEXT, ip_address TEXT, ram INTEGER DEFAULT 1024, disk INTEGER DEFAULT 10240, cores INTEGER DEFAULT 1, created_at TEXT)')
c.execute('CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT)')
c.execute('CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY, time TEXT, level TEXT, message TEXT)')
conn.commit()

# default admin
admin_pass = hashlib.sha256("adm7800".encode()).hexdigest()
c.execute('INSERT OR IGNORE INTO users (id, username, password, role, ref_code) VALUES (1, "admin", ?, "admin", "ADMIN")', (admin_pass,))
c.execute('INSERT OR IGNORE INTO config (key, value) VALUES ("copyright", "© Zynex Team by MrDraynoX")')
c.execute('INSERT OR IGNORE INTO config (key, value) VALUES ("logo", "/static/uploads/default_logo.png")')
c.execute('INSERT OR IGNORE INTO config (key, value) VALUES ("background", "/static/uploads/default_bg.png")')
conn.commit()

def hash_pw(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()

def log(level: str, message: str):
    t = datetime.datetime.utcnow().isoformat()
    c.execute('INSERT INTO logs (time, level, message) VALUES (?, ?, ?)', (t, level, message))
    conn.commit()

def get_config(key: str):
    c.execute('SELECT value FROM config WHERE key=?', (key,))
    r = c.fetchone()
    return r[0] if r else None

@app.get('/', response_class=HTMLResponse)
def index(request: Request):
    logo = get_config("logo")
    bg = get_config("background")
    copyright_text = get_config("copyright")
    return templates.TemplateResponse("index.html", {"request": request, "logo": logo, "background": bg, "copyright": copyright_text})

@app.get('/register', response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post('/register')
def register(username: str = Form(...), password: str = Form(...), email: str = Form(None)):
    pw = hash_pw(password)
    ref_code = str(uuid.uuid4())[:8]
    try:
        c.execute('INSERT INTO users (username, password, email, ref_code) VALUES (?, ?, ?, ?)', (username, pw, email, ref_code))
        conn.commit()
        log("INFO", f"User registered: {username}")
    except Exception:
        raise HTTPException(status_code=400, detail="Username already exists")
    return RedirectResponse(url='/login', status_code=303)

@app.get('/login', response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post('/login')
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    pw = hash_pw(password)
    c.execute('SELECT id, role FROM users WHERE username=? AND password=?', (username, pw))
    r = c.fetchone()
    if not r:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    user_id, role = r
    if role == "admin":
        log("INFO", f"Admin login: {username}")
        return RedirectResponse(url=f"/admin?user_id={user_id}", status_code=303)
    log("INFO", f"User login: {username}")
    return RedirectResponse(url=f"/dashboard?user_id={user_id}", status_code=303)

@app.get('/dashboard', response_class=HTMLResponse)
def dashboard(request: Request, user_id: int):
    c.execute('SELECT username, email, role FROM users WHERE id=?', (user_id,))
    user = c.fetchone()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    username, email, role = user
    c.execute('SELECT id, user_id, name, os, status, ip_address, ram, disk, cores, created_at FROM vps WHERE user_id=?', (user_id,))
    vps = c.fetchall()
    return templates.TemplateResponse("dashboard.html", {"request": request, "user_id": user_id, "username": username, "email": email, "role": role, "vps": vps})

# Note: Users cannot deploy. Only admin can create VPS.
@app.post('/deploy')
def deploy_forbidden(user_id: int = Form(...), name: str = Form(...), os_choice: str = Form(...), ram: int = Form(1024), disk: int = Form(10240), cores: int = Form(1)):
    raise HTTPException(status_code=403, detail="Only admins can create VPS. Use admin panel.")

@app.post('/vps_action')
def vps_action(action: str = Form(...), vps_id: int = Form(...), user_id: int = Form(...)):
    c.execute('SELECT user_id, name FROM vps WHERE id=?', (vps_id,))
    r = c.fetchone()
    if not r:
        raise HTTPException(status_code=404, detail='VPS not found')
    owner, name = r
    if owner != user_id:
        c.execute('SELECT role FROM users WHERE id=?', (user_id,))
        rr = c.fetchone()
        if not rr or rr[0] != 'admin':
            raise HTTPException(status_code=403, detail='Forbidden')
    if action == 'start':
        c.execute('UPDATE vps SET status="running" WHERE id=?', (vps_id,))
        log('INFO', f'VPS start: {vps_id} by {user_id}')
    elif action == 'stop':
        c.execute('UPDATE vps SET status="stopped" WHERE id=?', (vps_id,))
        log('INFO', f'VPS stop: {vps_id} by {user_id}')
    elif action == 'reboot':
        c.execute('UPDATE vps SET status="rebooting" WHERE id=?', (vps_id,))
        log('INFO', f'VPS reboot: {vps_id} by {user_id}')
    elif action == 'delete':
        # only admin or owner can delete
        c.execute('SELECT role FROM users WHERE id=?', (user_id,))
        rr = c.fetchone()
        if owner != user_id and (not rr or rr[0] != 'admin'):
            raise HTTPException(status_code=403, detail='Forbidden')
        c.execute('DELETE FROM vps WHERE id=?', (vps_id,))
        log('WARN', f'VPS deleted: {vps_id} by {user_id}')
    else:
        raise HTTPException(status_code=400, detail='Unknown action')
    conn.commit()
    return RedirectResponse(url=f'/dashboard?user_id={user_id}', status_code=303)

@app.get('/admin', response_class=HTMLResponse)
def admin_page(request: Request, user_id: int):
    c.execute('SELECT role FROM users WHERE id=?', (user_id,))
    r = c.fetchone()
    if not r or r[0] != 'admin':
        raise HTTPException(status_code=403, detail='Forbidden')
    c.execute('SELECT id, username, role, email, ref_code FROM users')
    users = c.fetchall()
    c.execute('SELECT id, user_id, name, os, status, ip_address, ram, disk, cores, created_at FROM vps')
    vps = c.fetchall()
    c.execute('SELECT time, level, message FROM logs ORDER BY id DESC LIMIT 200')
    logs = c.fetchall()
    return templates.TemplateResponse('admin.html', {'request': request, 'users': users, 'vps': vps, 'logs': logs})

@app.post('/admin_create_vps')
def admin_create_vps(user_identifier: str = Form(...), name: str = Form(...), os_choice: str = Form(...), ram: int = Form(1024), disk: int = Form(10240), cores: int = Form(1), admin_id: int = Form(...)):
    c.execute('SELECT role FROM users WHERE id=?', (admin_id,))
    r = c.fetchone()
    if not r or r[0] != 'admin':
        raise HTTPException(status_code=403, detail='Forbidden')
    user_id = None
    try:
        uid = int(user_identifier)
        c.execute('SELECT id FROM users WHERE id=?', (uid,))
        rr = c.fetchone()
        if rr:
            user_id = rr[0]
    except:
        c.execute('SELECT id FROM users WHERE username=?', (user_identifier,))
        rr = c.fetchone()
        if rr:
            user_id = rr[0]
    if not user_id:
        raise HTTPException(status_code=404, detail='Target user not found')
    if os_choice.lower() not in ('ubuntu', 'debian'):
        raise HTTPException(status_code=400, detail='Unsupported OS')
    ip = f"10.20.{random.randint(1,254)}.{random.randint(1,254)}"
    created = datetime.datetime.utcnow().isoformat()
    c.execute('INSERT INTO vps (user_id, name, os, status, ip_address, ram, disk, cores, created_at) VALUES (?, ?, ?, "running", ?, ?, ?, ?, ?)', (user_id, name, os_choice, ip, ram, disk, cores, created))
    conn.commit()
    log('INFO', f'Admin {admin_id} created VPS {name} for user {user_id} (ram={ram}MB disk={disk}MB cores={cores})')
    return RedirectResponse(url=f'/admin?user_id={admin_id}', status_code=303)

@app.post('/change_password')
def change_password(username: str = Form(...), old_password: str = Form(...), new_password: str = Form(...)):
    c.execute('SELECT password FROM users WHERE username=?', (username,))
    r = c.fetchone()
    if not r or r[0] != hash_pw(old_password):
        raise HTTPException(status_code=401, detail='Invalid credentials')
    c.execute('UPDATE users SET password=? WHERE username=?', (hash_pw(new_password), username))
    conn.commit()
    log('INFO', f'Password changed for {username}')
    return RedirectResponse(url='/login', status_code=303)

@app.post('/upload_branding')
def upload_branding(user_id: int = Form(...), logo: UploadFile = File(None), background: UploadFile = File(None)):
    c.execute('SELECT role FROM users WHERE id=?', (user_id,))
    r = c.fetchone()
    if not r or r[0] != 'admin':
        raise HTTPException(status_code=403, detail='Forbidden')
    if logo:
        fn = f'static/uploads/{uuid.uuid4().hex}_{logo.filename}'
        with open(fn, 'wb') as f:
            f.write(logo.file.read())
        c.execute('REPLACE INTO config (key, value) VALUES ("logo", ?)', (f'/{fn}',))
    if background:
        fn2 = f'static/uploads/{uuid.uuid4().hex}_{background.filename}'
        with open(fn2, 'wb') as f:
            f.write(background.file.read())
        c.execute('REPLACE INTO config (key, value) VALUES ("background", ?)', (f'/{fn2}',))
    conn.commit()
    log('INFO', f'Branding updated by admin {user_id}')
    return RedirectResponse(url=f'/admin?user_id={user_id}', status_code=303)

@app.get('/ssh_connect', response_class=HTMLResponse)
def ssh_connect(request: Request, vps_id: int, user_id: int):
    c.execute('SELECT ip_address, name FROM vps WHERE id=?', (vps_id,))
    r = c.fetchone()
    if not r:
        raise HTTPException(status_code=404, detail='VPS not found')
    ip, name = r
    cmd = f'ssh root@{ip} -p 22'
    return templates.TemplateResponse('ssh.html', {'request': request, 'cmd': cmd, 'vps_name': name, 'user_id': user_id})

# placeholder files
open('static/uploads/default_logo.png', 'ab').close()
open('static/uploads/default_bg.png', 'ab').close()
