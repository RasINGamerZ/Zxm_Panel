# Zxm Panel v1 UI

Improved UI with animations, rain effect, and admin-only VPS creation.

## Requirements
- Ubuntu 20.04+
- Python 3.9+

## Install
unzip Zxm_panel_v1_ui.zip && cd Zxm_panel_v1_ui
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
bash run.sh
Open http://localhost:8000

Default admin: admin / adm7800
