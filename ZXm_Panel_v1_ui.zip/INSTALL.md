
# Zxm_Panel — Installation Guide

This package was standardized to **Zxm_Panel** filenames and includes a modern CSS plus a favicon.

## Contents
- `assets/css/Zxm_Panel.css` — modern UI stylesheet
- `assets/img/icon.png` — placeholder favicon / brand icon
- Your project files (HTML, JS, assets) — filenames normalized where applicable.

## Quick Install (static / local)
1. Unzip the package.
2. Open `index.html` (or the main HTML file) in your browser:
   - `file:///path/to/Zxm_Panel_v1_ui/index.html`
3. If assets don't load, ensure the `assets/` folder sits next to your HTML files.

## Install on a web server (Apache / Nginx)
1. Upload the full folder to your web root (e.g. `/var/www/html/Zxm_Panel/`).
2. Ensure ownership and permissions:
   ```bash
   sudo chown -R www-data:www-data /var/www/html/Zxm_Panel
   sudo chmod -R 755 /var/www/html/Zxm_Panel
   ```
3. Visit `https://your-domain.com/Zxm_Panel/` — the `index.html` will be served.

## Notes & Next Steps
- If your project references specific JS or CSS filenames that were renamed, double-check those references (they were automatically updated where possible).
- Replace `assets/img/icon.png` with your real icon (recommended sizes: 32x32, 128x128, 256x256).
- For a production-grade UI, consider integrating Tailwind or a CSS framework and optimizing images.

---

Produced on the server.
