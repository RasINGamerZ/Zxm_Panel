
document.addEventListener('DOMContentLoaded', function(){
  try{ document.body.classList.add('fade-in'); }catch(e){}
  try{
    document.querySelectorAll('img').forEach(function(img){
      if(img.src && /power-?port/i.test(img.src)){
        img.src = "https://media.discordapp.net/attachments/1423301812336988182/1424684647723569293/file_0000000044b8622f8e323e019de.png";
      }
    });
  }catch(e){}
});
