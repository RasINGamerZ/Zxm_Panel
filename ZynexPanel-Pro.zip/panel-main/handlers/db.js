const Keyv = require('keyv');
const db = new Keyv('sqlite://zynexpanel.db');

module.exports = { db }